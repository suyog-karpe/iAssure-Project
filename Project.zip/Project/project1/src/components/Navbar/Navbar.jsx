import React from 'react'
import './Navbar.css'
import logo from '../../assets/Logo.png'
import logo1 from '../../assets/log1.png'
const Navbar = () => {
  return (
    <>
    <div className='navbar1'>
      <img src={logo1} alt='' className='pov'/>
    </div>
    <div className='navbar'>
      <img src={logo} alt='' className='logo'/>
      <ul>
        <li>HOME</li>
        <li>ABOUT US</li>
        <li>SERVICES</li>
        <li>TESTIMONIALS</li>
        <li>BLOGS</li>
        <li>CONTACT</li>
      </ul>
      
    </div>
    </>
  )
}

export default Navbar
