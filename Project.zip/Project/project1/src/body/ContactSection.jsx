import React from 'react'


const ContactSection = () => {
  return (
    <div className='container'>
      <div className='containSection__wrapper'>
        <div className='left'>
            

        </div>
        <div className='right'>
            Contact Form

        </div>
      </div>
    </div>
  )
}

export default ContactSection
