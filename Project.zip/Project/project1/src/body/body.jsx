import React from 'react'
import ContactSection from './ContactSection'
import './body.css'

const body = () => {
  return (
    <>
    <div>
        <ContactSection/>
    </div>
    <div className='mapper'>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4499.511361574722!2d73.81986509093652!3d18
        .500729487598207!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bfebabe7ae85%3A0x3ea0f311fed26903!2sSIDDHARTH%
        20TOWER%2C%20Paschimanagri%2C%20Kothrud%2C%20Pune%2C%20Maharashtra%20411038!5e0!3m2!1sen!2sin!4v1704026654809!5m2!1sen!2sin" width="100%" 
        height="450" style={{border:0}} allowFullScreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <div className ='body-div'>
        <footer/>
    </div>
    </>
  )
}

export default body
