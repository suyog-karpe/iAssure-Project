import React from 'react'
import {MdPlace} from 'react-icons/md'
import PText from './PText';

const ContactInfoItem = () => {
  icon= <MdPlace/>,
  text='thi is an info'
})

  return (
    <div>
        <div className='icon'>{icon}</div>
        <div className='info'>
          <PText>{text}</PText>
        </div>
    </div>
  )
}

export default ContactInfoItem
