import React from 'react'
import Navbar from './components/Navbar/Navbar'
import './components/Navbar/Navbar.css'
import jpeg from './assets/img1.jpg'
import './index.css'
import './App.css'
import Body from './body/body.jsx'
import Footer from './footer/footer.jsx'


const App = () => {
  const myfun=()=>{
    alert('hello');
  }
  return (
    <>
    <Navbar/>
    <div>
      <div className='jpeg'>
        <img src={jpeg} alt='' className='pov' width='100%' height='230px'/>
        <div className='jpeg-text'>
          <h3>Contact Us</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.<br/>
             Reprehenderit tempore, adipisci sapiente sunt minus aliquid.</p>
          <button className='button-id ' variant='contained'
          onClick={myfun}>Home >> Contact Us</button>
        </div>
      </div>
    </div>
    <Body/>
    <Footer/>
    </>
  )
}

export default App

