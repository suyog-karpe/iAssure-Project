import React from 'react';
import './footer.css';
import linkedin from '../assets/Linkedin.png'
import Email from '../assets/Email.png'
import twitter from '../assets/Twitter.png'
import website from '../assets/website.png'



const footer = () => {
  return (
    <div className='footer'>
        <div className ='sb_footer section_padding'>
            <div className='sb_footer-links'>
                <div className='sb_footer-links-div'>
                    <h4>Follow Us</h4>
                    <div className='socialmedia'>
                        <p><img src={linkedin} alt=''/></p>
                        <p><img height='80vh' src={Email} alt=''/></p>
                        <p><img height='80vh'src={twitter} alt=''/></p>
                    </div>
                    <div className='website-size'>
                        <p><img src={website} alt=''/></p>
                        <a href="https://iassureit.com/">iassureit.com/</a>
                    </div>
                </div>
                <div className='sec-body'>
                    <h4>Our Services</h4>
                    <br></br>
                    <div className='third-body'>
                        <p>>>Lorem, ipsum dolor.</p>
                        <p>>>Lorem, ipsum dolor.</p>
                        <p>>>Lorem, ipsum dolor.</p>
                        <p>>>Lorem, ipsum dolor.</p>
                    </div>
                </div>

            </div>   
        </div>   
    </div>
  );
}

export default footer
